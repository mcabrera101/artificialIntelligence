#!/usr/bin/env python
#Miguel Cabrera

"""this module does """
from main import main

if __name__ == '__main__':
    main()
    